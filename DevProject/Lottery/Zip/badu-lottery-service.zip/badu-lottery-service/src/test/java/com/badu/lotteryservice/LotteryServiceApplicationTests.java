package com.badu.lotteryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotteryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
